import readline
import time
import os

os.chdir("/storage/emulated/0")



def folback():
    follis=os.getcwd().split("/")
    osch=""
    for i in range(len(follis)-1):
        osch+=follis[i]
        osch+="/"
    try :
        os.chdir(osch)
        print("Your Current directory is changed to {0}".format(os.getcwd()))
    except FileNotFoundError :
        print("Directory ' {0} ' dose not exist .".format(inp))
    except NotADirectoryError :
        print("' {0} ' is not a directory .".format(inp))
    except PermissionError :
        print("You do not have permissions to change to {0}".format(inp))





def opner():
    
    folbktf=False
    print('Your current directory is " {0} "\n'.format(os.getcwd()))
    inp=input("Enter :\n showfol for showing folders or\n showfil for showing files or\n writedir of for writing directory path \n: ")
    while True :
        if folbktf:
            if inp=="folback":
                folback()
            if inp =="writedir" :
                inp=str(input("Enter the directory for changing diroctry\n : "))
                try :
                    os.chdir(inp)
                    print("Your Current directory is changed to {0}".format(os.getcwd()))
                except FileNotFoundError :
                    print("Directory ' {0} ' dose not exist .".format(inp))
                except NotADirectoryError :
                    print("' {0} ' is not a directory .".format(inp))
                except PermissionError :
                    print("You do not have permissions to change to {0}".format(inp))
            
                
                
        if inp=="showfol":
            try :
                ffl=os.listdir()
                i=1
                ffln=[]
                fflck=[]
                for f in ffl:
                    try :
                        for word in f:
                            if word==".":
                                a=giveerror()
                            else :
                                break
                        try :
                            f.split(".")[1]
                            pass
                        except:
                            ffln.append(f)
                            print(f"{i} : {f}")
                            fflck.append(f)
                            i+=1
                    except :
                        pass
                if fflck !=[]:
                    while True:
                        try :
                            inp=int(input("Enter the number of file you want to open \n: "))
                            break
                        except :
                            print("Please enter only number")
                    os.chdir(ffln[inp-1])
                    print("Your Current directory is changed to {0}".format(os.getcwd()))
                elif fflck==[]:
                    print("Not any file found !")
            except FileNotFoundError :
                print("Directory ' {0} ' dose not exist .".format(inp))
            except NotADirectoryError :
                print("' {0} ' is not a directory .".format(inp))
            except PermissionError :
                print("You do not have permissions to change to {0}".format(inp))
            
                
        elif inp=="showfil":
            try:
                ffl=os.listdir()
                i=1
                fflck=[]
                for f in ffl:
                    try :
                        for word in f:
                            if word==".":
                                a=giveerror()
                            else :
                                break
                        try :
                            f.split(".")[1]
                            print(f"{i} : {f}")
                            fflck.append(f)
                            i+=1
                        except:
                            pass
                    except :
                        pass
                if fflck !=[]:
                    while True:
                        inp=input("Enter the number or name of file you want to open \n: ")
                        str(inp)
                        #try :
        #                    str(inp)
        #                    file_reader(inp,True)
        #                    break
        #                except :
        #                    int(inp)
        #                    print(ffl[inp-1])
        #                    file_reader(ffl[inp-1],False)
        #                    break
        #                except :
        #                    print("You enterd something wrong ")
                elif fflck==[]:
                        print("Not any file found !")
            except FileNotFoundError :
                print("Directory ' {0} ' dose not exist .".format(inp))
            except NotADirectoryError :
                print("' {0} ' is not a directory .".format(inp))
            except PermissionError :
                print("You do not have permissions to change to {0}".format(inp))
            
        
        if os.getcwd()=="/storage/emulated/0":
            folbktf=False
            inp=input("Enter :\n showfol for showing folders or\n showfil for showing files or\n writedir of for writing directory path \n: ")
        else :
            folbkft=True
            inp=input("Enter :\n showfol for showing folders or\n showfil for showing files or\n writedir of for writing directory path or \n folback for one folder back\n: ")
            




def file_reader(file,fname):
    if fname:
        pass
    elif not fname:
        pass
    else :
        print("Something went wrong please try again ×_× ")





def e_w_f( text):
    def hook():
        readline.insert_text(text)
        readline.redisplay()
    readline.set_pre_input_hook(hook)
    result = input()
    readline.set_pre_input_hook()
    return result






if __name__ =="__main__":
    opner()