import smtplib
import imghdr
from email.message import EmailMessage


msg=EmailMessage()
msg["Subject"]="emails with python"
msg["From"]="pythontesting0101@gmail.com"
msg["To"]="pythontesting0101@gmail.com"
msg.set_content("This is email message python radha Radhe ")

files=['img1.jpg','img2.jpg','img3.jpg']

for file in files:
    with open(file,"rb") as f:
        file_data=f.read()
        file_type=imghdr.what(f.name)
        file_name = f.name 
    
    msg.add_attachment(file_data,maintype ='image ',subtype =file_type,filename =file_name)



with smtplib.SMTP_SSL("smtp.gmail.com",465) as smtp:
    
    smtp.login("pythontesting0101@gmail.com","thisisforpython0101test")
    smtp.send_message(msg)