'''
          Made by PRASHANT RAWAT        
                  ORIGINAL TicTacToe 
      Without help of Google Or YouTube 
      		 		30 May 2022 					     
      		 														  '''

def win(Xm,Om): # Function to check if any player win 
	if Xm[0] == Xm[1] == Xm[2] == "X" or Xm[3] == Xm[4] == Xm[5] == "X" or Xm[6] == Xm[7] == Xm[8] == "X" or Xm[0] == Xm[3] == Xm[6] == "X" or Xm[1] == Xm[4] == Xm[7] == "X" or Xm[2] == Xm[5] == Xm[8] == "X" or Xm[0] == Xm[4] == Xm[8] == "X" or Xm[2] == Xm[4] == Xm[6] == "X"  :
		print ("\t\t``''°•~-,,_$ X WIN $_,,-~•°''``")
		return True

	elif Om[0] == Om[1] == Om[2] == "O" or Om[3] == Om[4] == Om[5] == "O" or Xm[6] == Om[7] == Om[8] == "O" or Om[0] == Om[3] == Om[6] == "O" or Om[1] == Om[4] == Om[7] == "O" or Om[2] == Om[5] == Om[8] == "O" or Om[0] == Om[4] == Om[8] == "O" or Om[2] == Om[4] == Om[6] == "O"  :
		print ("\t\t``''°•~-,,_$ O WIN $_,,-~•°''``")
		return True


def counter(Xm,Om,num):#Decide what will come on place of every digit on dashboard
	if Xm[num-1]=="X":
		return "X"
	elif Om[num-1]=="O":
		return "O"
	else :
		return num


def dashboard(Xm ,Om): # prints board of TicTacToe
	one =  counter(Xm,Om,1)
	two =  counter(Xm,Om,2)
	three =  counter(Xm,Om,3)
	four =  counter(Xm,Om,4)
	five =  counter(Xm,Om,5)
	six =  counter(Xm,Om,6)
	seven =  counter(Xm,Om,7)
	eight =  counter(Xm,Om,8)
	nine =  counter(Xm,Om,9)
	
	print ("\n\n")
	print (f"\t\t    {one}   |   {two}   |   {three} ")
	print ("\t\t   ___________________\n")
	print (f"\t\t    {four}   |   {five}   |   {six} ")
	print ("\t\t   ___________________\n")
	print (f"\t\t    {seven}   |   {eight}   |   {nine} ")
	print ("\n\n")


if __name__ == "__main__" :
	print ("	   	Made by PRASHANT RAWAT \n	    	  ORIGINAL TicTacToe \n  	   Without help of Google Or YouTube \n			      		       ~30 May 2022")
	
	Xm = [1,2,3,4,5,6,7,8,9]
	Om = [1,2,3,4,5,6,7,8,9]
	turn= 1 #1 for x & 0 for O
	dashboard (Xm , Om)
	
	while True :
		if turn :
			xmove = int (input ("X turn : ")) - 1# take player's input
			if Om[xmove ] == "O" or Xm[xmove ] == "X" :
				print ("Already entered ") #check if it is already entered
			else :
				Xm[xmove ] = "X"
				dashboard (Xm , Om)
				turn=0
				
		else :
			omove = int (input ("O turn : ")) - 1
			if Om[omove ] == "O" or Xm[omove ] == "X"  :
				print ("Already entered ")
			else :
				Om[omove ] = "O"
				dashboard (Xm , Om)
				turn= 1 
		if win(Xm,Om):
			break #end game if any player win