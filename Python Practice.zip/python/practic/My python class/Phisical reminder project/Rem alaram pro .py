while True:
	from pygame import mixer
	mixer.init()
	mixer.music.load("1.mp3")
	mixer.music.play()
	while True:
		continue
	continue