import pygame
import time
pygame.init()

win = pygame.display.set_mode((500,500))
pygame.display.set_caption("First Game")

x = 50
y = 50
width = 40
height = 60
vel = 5

run = True

while run:
    pygame.time.delay(100)

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            run = False
    
    pygame.mixer.music.load("ud.mp3")
    pygame.mixer.music.play()
    time.sleep(5)
    
    
pygame.quit()