import random
import time
l=[chr(i) for i in range(50,128)]
lt=["   ", " ","       ","  ","   "," ","","   "," "," ","  ","","   ","","","  ","      ","\n"]
ltt=["   ", " ","        ","  ","   "," ","","   "," ","       ","  ","   "," ","","   "," "," ","  ","","   ","","","  ","      "]
h=0
while True :
    if random.randint(1,70) == 1:
        lt[random.randint(0,16)]=random.choice(ltt)
        lt[random.randint(0,16)]=random.choice(ltt)
        lt[random.randint(0,16)]=random.choice(ltt)
        lt[random.randint(0,16)]=random.choice(ltt)
        lt[random.randint(0,16)]=random.choice(ltt)
        lt[random.randint(0,16)]=random.choice(ltt)
    print(random.choice(l),end="")
    print(lt[h],end="")
    
    if random.randint(1,140)==10:
        print("\n")
    time.sleep(0.004)
    h+=1
    if h==18:
        h=0