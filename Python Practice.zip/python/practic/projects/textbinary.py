



def txttobinary(text):
    binary=''
    digs=[128,64,32,16,8,4,2,1]
    decimal=[chr(i) for i in range(128)]
    try :
        for ltr in text:
            indx=decimal.index(ltr)
            for dig in digs:
                if indx>=dig:
                    indx-=dig
                    binary+='1'
                else :
                    binary+='0'
            binary+=' '
        return binary
    except Exceptation as e:
        return " An Error occoure : {0}".format(e)
    
def binarytotxt(binary):
    string=''
    digs=[128,64,32,16,8,4,2,1]
    decimal=[chr(i) for i in range(128)]
    bny=binary.split(" ")
    try :
        for ltr in bny:
            i=0
            dcmlch=0
            for dgt in ltr:
                if int(dgt)==1:
                    dcmlch+=digs[i]
                i+=1
            string+=decimal[dcmlch]
        return string
    except Exception as e:
        return " An Error occoure : {0}".format(e)
        
            
while True:
    inp=input("\nEnter btt for converting binary value to text or ttb for converting text to binary value \n: ")
    if inp=='ttb':
        inp=input("Enter the text \n:")
        print(txttobinary(inp))
        if pcch():
            pc.copy(txttobinary(inp))
    elif inp=='btt':
        inp=input("Enter the binary value \n:")
        print(binarytotxt(inp))
    else :
        print('enter only ttb or bbt')

