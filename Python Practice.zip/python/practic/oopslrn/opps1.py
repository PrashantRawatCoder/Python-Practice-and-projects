class Fammem():
	def __init__(self,name,age):
		self.name = name
		self.age = age


gopu = Fammem("Gopu",2)
mom = Fammem("Rekha",34)
papa = Fammem("Bisamber",44)
nana = Fammem("Ashu Tosh",70)
usha = Fammem("Usha",14)
prashant = Fammem("Prashant Rawat",12)


print(nana.age)