class Laptop:
    
    def __init__(self,name,model,price):
        self.name=name
        self.model=model
        self.price=price

lapa=Laptop("lapo","lap123",20)