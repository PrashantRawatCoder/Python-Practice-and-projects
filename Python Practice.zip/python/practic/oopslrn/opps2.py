class Fammem():
	ageyr=1
	def __init__(self,name,age):
		self.name = name
		self.age = age
		self.agemon=1/12
	def ageadd(self,mon,yer):
		if yer:
			self.age +=Fammem.ageyr
		elif mon:
			self.age +=self.agemon


gopu = Fammem("Gopu",2)
print(gopu.age)
gopu.ageadd(False,True)
print(gopu.age)
mom = Fammem("Rekha",34)
papa = Fammem("Bisamber",44)
nana = Fammem("Ashu Tosh",70)
usha = Fammem("Usha",14)
prashant = Fammem("Prashant Rawat",12)





#print(nana.__dict__)
#print(Fammem.__dict__)