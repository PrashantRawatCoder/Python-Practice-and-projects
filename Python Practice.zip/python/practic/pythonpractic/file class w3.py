#f = open ("hahiho.txt","w")
#f.write("hare krishana")
#f.close ()
f = open ("hahiho.txt","a")
f.write("hare krishana \n")
f.close ()
f = open ("hahiho.txt","a")
a= f.write("hare krishana")
print (a)
f.close ()




