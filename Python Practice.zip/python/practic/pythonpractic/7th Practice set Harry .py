"""
Author : Prashant Rawat
Age : 12
Date : 15 Jan 2021
Purpos : For practice
"""


from time import time
while True:
#time counter
	timecou=time()
#score counter
	def searcher(sen1,sen2):
		words1=sen1.split(" ")
		words2=sen2.split(" ")
		
		score = 0
		
		for word1 in words1:
			for word2 in words2:
				if word1.lower()==word2.lower():
					score+=1
		return score
	
#main searcher
	if __name__=="__main__":
		
		list=["You are  mentaly disorder ","Python is good","Radhe radhe krishna","Krishana radhe","Python is my first programming language" , "My name is prashant rawat","But python is not python snake"]
		
		inp=input("What you want to search:\n")
		scores=[searcher(inp,lis) for lis in list]
	#	print(scores)
		sortedsentscore=[sentscore for sentscore in 				sorted(zip(scores,list),reverse=True ) if sentscore[0] != 0]
	#	print(sortedsentscore)
		timecoued=time()-timecou
		print(f"{len(sortedsentscore)} items found in 0.{int(timecoued)} second :\n")
		for scor,item in sortedsentscore:
			print(f"{item} with {scor} score .")
	# Ask for continue or quit
	usin=input("\n\nEnter \"C\" for continue or \"Q\" for quit :\n")
	if usin=="Q":
		exit()


