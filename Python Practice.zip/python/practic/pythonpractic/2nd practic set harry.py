def su(a,b,c):
	if b==c:
		if b%a==0:
			print(f"{b} and is diviseble")
		else:
			print(f"{b} and is not div")
	elif b != c:
		k=(c-b)+1
		for i in range(k):
			if (i+b)%a == 0:
				print(f"{i+b} is div")
			elif (i+b)%a!=0:
				print(f"{i+b} is not div")


print("\t\t  Welcome\n")
while True:
	try:
		o=int(input("\nEnter num of childs :\n"))
		p=int(input("enter mimumim num of apple :\n"))
		g=int(input("enter mexemum num of apple :\n"))
		su(o,p,g)
		r=input("Enter 'c' for continue 'q' for quit :\n")
		if r=="q":
			break
		else :
			continue
	except:
		print("Something went wrong please try again ")
		continue








