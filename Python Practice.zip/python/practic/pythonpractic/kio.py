
def kio (k) :
	while True:
		a = 3
		b= int (input ("enter 1 for play num \n= "))
		while b==1:
			d=0
			a=(a+ (a- (a-3)))*a
			a//=4
			if b<=4:
				b= int (input ("enter 1 for random num \n= "))
				a +=1 
				a*=5
				print (a//2*2)
			else:
				a=0
			d+=1