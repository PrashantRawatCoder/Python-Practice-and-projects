"""
Author : Prashant Rawat 
Age : 12 
Date : 13 Jan 2021
"""

while True:
	def sp(dh):
		dh=dh+1
		while not ip(dh):
			dh=dh+1
		return dh	
	def ip(dh):
		return str(dh) == str(dh)[::-1]	
	if __name__=="__main__":
		a=int(input("Enter how many cases you want :\n"))
		l=[]
		for i in range(a):
			l.append(int(input("enter the numder :\n")))
		for i in range(a):
			print(f"The palimdrom of {l[i]} is {sp(l[i])}")
	vh=input("Enter 'c' for continue or 'q' for quit :\n")
	if vh=="q":
		exit()