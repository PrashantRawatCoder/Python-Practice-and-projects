print("shri radhe")
o=int(input("how many row "))
print("1or0")
n=int(input())
k=bool(n)
if n == True :
	for i in range (1,o+1):

		for j in range (1,i+1):
			print('*',end=" ")
		print()
elif n == False :
	for i in range (o,0,-1):
		for j in range (i+1):
			print('*',end="")
		print()