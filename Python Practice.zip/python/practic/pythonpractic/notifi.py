import time 
from plyer import notification
if __name__ == "__main__":
	while True :
		notification.notify (
		title = "** Please Drink Water now !!",
		message = "radhe radhe \njarur piyo abhi" ,
		app_icon = "Phone/pyt/noti.jpg",
		timeout = 4
		)
		time.sleep(6)