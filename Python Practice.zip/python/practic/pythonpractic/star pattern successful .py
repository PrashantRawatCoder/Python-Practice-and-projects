a=0
b=0
c=int(input("How many row you want to print :\n"))
k=int(input("Type 1 or 0 :\n"))
if k==1:
	for I in range (c):
		for j in range (a+1):
			print("*",end=" ",)
		print()
		a=a+1

elif k==0:
	while c>b:
		for j in range ((c-1)+1):
			print("*",end=" ",)
		print()
		c=c-1