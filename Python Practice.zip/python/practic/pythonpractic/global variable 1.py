l = 10


#def function1 (n):
#	print ()
#	
#	print (n," radhe radhe")

#function1 ("krishna ")

#def function1 (n):
#	print (l)
#	
#	print (n," radhe radhe")

#function1 ("krishna ")
#def function1 (n):
#	l=5
#	
#	
#	print (l)
#	
#	print (n," radhe radhe")

#function1 ("krishna ")
#def function1 (n):
#	l=5
#	m=2
#	
#	print (l,m)
#	
#	print (n," radhe radhe")

#function1 ("krishna ")
#print (m) #this is error
def function1 (n):
#	l=5
	m=2
	global l
	l=l+45
	print (l,m)
	
	print (n," radhe radhe")

function1 ("krishna ")






