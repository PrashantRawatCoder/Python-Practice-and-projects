st=int(input("Enter how long you want to keep the list :\n"))
l=[]
for i in range (st):
	l.append(input("Enter the element :\n"))
ir=l[:]
ir.reverse()
print(f"First reverse of {l} is {ir}")
sr=l[::-1]
print(f"Second reverse of {l} is {sr}")
tr=l[:]
for i in range (len(tr)//2) :
	tr[i],tr[len(tr)-1-i]=tr[len(tr)-1-i],tr[i]
print(f"Third reverse of {l} is {tr}")
if ir==sr and ir==tr:
	print("All reverse are same ")