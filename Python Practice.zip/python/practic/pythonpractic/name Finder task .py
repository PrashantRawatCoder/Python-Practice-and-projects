a= input("Enter your name to find :\n")

def nf():
	import time
	time.sleep (4)
	nl="Gopal , Harry , Prashant , Python ,  "
	
	while True:
		s=(yield)
		if s in nl:
			print("ya your name finded in the book ")
		else:
			print("no your name not find in the book")

n= nf()
next(n)
n.send(a)
n.close()
