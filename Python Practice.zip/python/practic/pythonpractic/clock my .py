from __future__ import print_function
import datetime
d=datetime.datetime.now()
while True:
	if d==d:
		print(d)
	else :
		d=datetime.datetime.now()