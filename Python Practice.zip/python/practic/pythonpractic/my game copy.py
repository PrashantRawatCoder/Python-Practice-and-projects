from kivy.app import App
from kivy.uix.widget import Widget

class KuGame (Widget) :
	pass

class KuApp(App) :
	def build(self) :
		return KuGame ()
		
KuApp ().run ()