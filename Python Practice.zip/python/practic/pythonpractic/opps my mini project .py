# Create a library class
# display book
# lend book - (who owns the book if not present)
# add book
# return book

# HarryLibrary = Library(listofbooks, library_name)


#dictionary (books-nameofperson)

# create a main function and run an infinite while loop asking
# users for their input

class lib :
	def __init__(self,lis,na):
		self.lis=lis
		self.na=na
		self.dic={}
	
	def lebk(self,bk,us):
		if bk not in self.dic.keys():
			self.dic.update ({bk:us})
			print("Lend detabase updated ! Take the book now.")
		else :
			print(f"Book is alredy taken by {self.lb(book)}")
	
	def sb(self):
		print(f"\tWelcom to {self.na} Library .\nWe have these book :")
		for na in self.na :
			print(na)
	
	def ab(self,bk):
		self.lis.append(bk)
		print("Book has been added .")
	
	def rebk(self,bk):
		self.lebk.pop(bk)

if __name__=="__main__":
	r=lib(["Shrimad Bhagwad Geeta","Ramayan","Geeta","Python","Shoodh Bhojan","Radhe"],"Shri Radhe")
	while True:
		print(f"Welcome to the {r.na} library. Enter your choice to continue")
		print("1. Display Books")
		print("2. Lend a Book")
		print("3. Add a Book")
		print("4. Return a Book")
		h=int(input())
		if h==1:
			
		
		a=input('Enter "c" for Continue or "q" for quit :\n')
		if a=="q":
			break






