print("\t\tWelcome to age dector \n")
while True:
	try:
		a=int(input("\nEnter your age or year of birth :\n"))
	except ValueError:
		print("Don't enter a string ")
		continue
	if a>1920 and a<2025:
		print(f"Aap {a+100} main 100 years ke ho jaoge ")
	
	elif a<100 :
		v=2021-a
		print(f"Aap {(2021-a)+100} main 100 years ke ho jaoge ")
	
	elif a>100 and a<500:
		print("You are alredy older than 100 \nAnd are you oldest person in the earth ")
	
	elif a>500 and a<1919:
		print("You are alredy older than 100 \nAnd are you oldest person in the earth ")
	
	elif a>2025:
		print("You are not born yet \n")
	
	b=input('Enter "c" for continue or "q" for quit :\n')
	if b=="c":
		continue
	else:
		break
