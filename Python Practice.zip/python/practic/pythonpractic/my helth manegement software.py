print ("	 Welcome to Helth Management Software \n")
while True :
	try :
		print ("\n	Enter \n1 For Writing \n2 For See File")
		df = int(input ("Enter :\n"))
		print ("Enter\n1 For = Radhe \n2 For = Usha rani\n3 For = Prashant Rawat")
		a = int(input ("Enter :\n"))
		if df ==1:
			print ("Ok \n\nEnter \n1 For = Food \n2 For = Exercise \nEnter :\n")
			b= int(input ())
			if b==1:
				print ("Ok \n\nEnter Time :\n")
				k= input()
				g= input ("Enter Food name :\n")
				if a==1 :
					with open ("radhe helth.txt","a") as rh:
						rh.write ("Time = "+k+" Food = "+g)
				elif a==2 :
					with open ("Usha helth.txt","a") as kh:
						kh.write ("Time = "+k+" Food = "+g)
				elif a==3 :
					with open ("prashant helth.txt","a") as ph:
						ph.write ("Time = "+k+" Food = "+g)
			elif b==2:
				print ("Ok \n\nEnter Time :\n")
				fn= input()
				gg= input ("Enter Exercise name :\n")
				if a==1 :
					with open ("radhe helth.txt","a") as rhe:
						rhe.write ("Time = "+fn+" Exersize = "+gg)
				elif a==2 :
					with open ("Usha helth.txt","a") as khe:
						khe.write ("Time = "+fn+" Exersize = "+gg)
				elif a==3 :
					with open ("prashant helth.txt","a") as phe:
						phe.write ("Time = "+fn+" \nExersize = "+gg)
			else :
				print ("You Enterd something wrong")
		elif df ==2:
			if a== 1:
				with open ("radhe helth.txt","r") as rh:
					ga=rh.readlines ()
					print(ga)
			elif a == 2 :
				with open ("Usha helth.txt","r") as khe:
					ma =khe.readlines ()
					print (ma)
			elif a == 3 :
				with open ("prashant helth.txt","r") as ph:
					na= ph.readlines ()
					print (na)
			else :
				print ("You Enterd something wrong")
		
		else :
				print ("You Enterd something wrong")

	except Exception as ho :
		print ("""You Enterd" """,ho,""" " wrong \n""")
	gha= int(input("\nDo You want more :\nEnter = 1 For Yes \nEntre = 2 For No \n: "))
	if gha == 2: 
		break
	else:
		continue