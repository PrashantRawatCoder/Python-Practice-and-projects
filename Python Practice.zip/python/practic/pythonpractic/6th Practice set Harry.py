"""
Author : Prashant Rawat 
Age : 12 
Date : 14 Jan 2021
Name : Guess the number
"""


# Generate two random number (rn,rnt) between a to b -->

import random
a=int(input("Enter number a :\n"))
b=int(input("Enter number b :\n"))
rn=random.randint(a,b)
rnt=random.randint(a,b)
#l=[]
#for z in range((b-a)+1):
#	l.append(a+z)
#rn=random.choice(l)
#rnt=random.choice(l)
#variables (first player move,second player move ,trials and i ) fp,sp,i ,tr

fp=1
i=0
sp=1
tr=0
# loop and game
while True:
	if i ==0:
		if tr<3:
			fi=int(input(f"\nPlayer 1 \nGusse the number between {a} and {b}:\n"))
			if fi<rn:
				print("Wrong number !\nEnter a Greater number")
				fp=fp+1
				tr=tr+1
				continue
			elif fi>rn:
				print("Wrong number !\nEnter a smaller number")
				fp=fp+1
				tr=tr+1
				continue
			elif fi==rn:
				print("Player 1 Completed in ",fp," move")
			i=i+1
			tr=0
			
		else:
			print("player 1 loos \n3 trails completed")
			tr=0
			i=i+1
	elif i==1:
		if tr<3:
			fi=int(input(f"\nPlayer 2\nGusse the number between {a} and {b}:\n"))
			if fi<rnt:
				print("Wrong number !\nEnter a Greater number")
				sp=sp+1
				tr=tr+1
				continue
			elif fi>rnt:
				print("Wrong number !\nEnter a smaller number")
				sp=sp+1
				tr=tr+1
				continue
			elif fi==rnt:
				print("Player 2 Completed in ",sp," move")
				break
		else:
			print("player 2 loos \n3 trails completed")
			break

#show who wins
if sp<fp:
	print("\n\t\tPlayer 2 win!")
elif sp>fp:
	print("\n\t\tPlayer 1 win!")
else:
	print("\n\t\tDono jeete")

