"""
Author : Prashant Rawat 
Age : 12 
Date : 13 Jan 2021
"""
# Parindrom
while True:
	def sp(dh):
		if dh<10:
			return dh
		else :
			dh=dh+1
			while not ip(dh):
				dh=dh+1
			return dh
	def ip(dh):
		if dh <10:
			return dh
		else:
			return str(dh) == str(dh)[::-1]	
	if __name__=="__main__":
		a=int(input("Enter how many cases you want :\n"))
		l=[]
		m=[]
		for i in range(a):
			l.append(int(input("enter the number :\n")))
			m.append(sp(l[i]))
	print(f"The palimdrom of \n{l} \nis \n{m}\n")
	vh=input("Enter 'c' for continue or 'q' for quit :\n")
	if vh=="q":
		exit()

