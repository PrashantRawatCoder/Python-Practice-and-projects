
a=input("Enter your first name :\n")
b=input("Enter your last name :\n")
class name:
	def __init__(self,fn,ln):
		self.fn=fn
		self.ln=ln
	
	def explain(self):
		return f"The employ is {self.fn} {self.ln}"
	
	@property
	def email(self):
		if self.fn == None and self.ln == None:
			return "Email is not found \nPlease remake it"
		return f"{self.fn}.{self.ln}@r,g_codig.com"

	@email.deleter
	def email(self):
		self.fn=None
		self.ln=None
	@email.setter
	def email(self,ot):
		print('setting')
		names=ot.split("a")[0]
		self.fn=names.split(".")[0]
		self.ln=names.split(".")[1]

s=name(a,b)
#print(s.fn)
#del s.email
s.email="s.m@r,g_coding.com"
print(s.email)
