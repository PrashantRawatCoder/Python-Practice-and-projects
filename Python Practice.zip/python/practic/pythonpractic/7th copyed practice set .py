def ser(sen1,sen2):
	wor=sen1.split(" ")
	word=sen2.split(" ")
	scor=0
	for wo in wor:
		for word2 in word:
			if wo.lower()==word2.lower():
				scor+=1
	return scor

if __name__=="__main__":
	sen=["Radhe Radhe","radhe krishna","hdj fje  i dj  dif rk ","ido dic k  di  fk "]
	inp=input("what you want to search :\n")
	us=[ser(sent,inp) for sent in sen ]
#	print(us)
	sss=[ss for ss in sorted(zip(us,sen), reverse =True ) if ss[0]!=0]
	print(f"{len(sss)} result found")
	for item ,us in sss:
		print (f" {us} with {100/(len(sss)/item)}%")
