"""
Author : Prashant Rawat 
Age : 12
Date : 16 Jan 2021
Purpos : For practicing
"""

from random import randint

def rohntab(num,lis):
#	generate a random number
	rannum=randint(1,10)
	#print(rannum)
	rantab=randint(num*rannum-5,num*rannum+5)
	#print(rantab)
	#Write the list
	for i in range (10):
		if i+1==rannum:
			lis.append(rantab)
		else:
			lis.append(num*(i+1))
	return lis

#check the table
def checker(lis,num):
	for i in range (len(lis)):
		if lis[i] != num*(i+1):
			print(f"Number - {lis[i]} is Wrong \nInsted of {lis[i]} real number is {num*(i+1)}")
			#print(num*i+1)


if __name__=="__main__":
	#main loop
	lis=[]
	inp=int(input("What tabel you want :\n"))
	print(rohntab(inp,lis))
	checker(lis,inp)