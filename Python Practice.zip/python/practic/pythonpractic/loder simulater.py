import time
class loder:
	@classmethod
	def se(cl,val):
		return cl(*val.spilt(" "))
	
	def lod():
		for val in se():
			time.sleep(0.5)
			print(se())
if __name__=="__main__":
	print(loder.lod("1 2 3 4 5 6"))








#class electronic:
#	to=12
#	def __init__(self,scr,pcb):
#		self.scr=scr
#		self.pcb=pcb
#	def po(self):
#		return f"The cost of scr is {self.scr}.and cost of pcb is {self.pcb}"
#class poc_gjt(electronic):
#	pass
#radhe=poc_gjt(500,400)
#print(radhe.po ())