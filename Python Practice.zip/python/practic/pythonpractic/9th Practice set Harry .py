import random


def fun(lis):
	seplis=[wor.split(" ") for wor in lis]
	selis=[]
	flis=[]
	slis=[]
	chl=[]
	num=0
	print("\t\tNames List" )
	for list in seplis :
		for word in list :
			selis.append(word)
	for i in range (len(selis)):
		if i%2==0:
			flis.append(selis[i])
		elif i%2!=0:
			slis.append(selis[i])
	
	for j in range (len(flis)):
		print(flis[j],end=" ")
		ranu=random.randint(0,len(slis)-1)
		if   ranu not in chl:
			print(slis[ranu])
			chl.append(ranu)
	
				
	return "\n"
	
if __name__=="__main__":
	
	lis=[]
	howinp=int(input("How many name you want to enter :\n"))
	for i in range(howinp):
		lis.append(input("Enter the name :\n"))
	print(fun(lis))