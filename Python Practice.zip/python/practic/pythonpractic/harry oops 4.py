class Computer :
	com_rs = 8000
	
	
	def  __init__ (self,pi,mo,cc,) :
		self.pi=pi
		self.mo=mo
		self.cc=cc
	
	
	
	def com_th(self):
		return f"The cost of pi4 is {self.pi}.\nThe cost of moniter is {self.mo} and\nThe cost of cable and cover is {self.cc}."
	
	
	
	@classmethod
	def seds (cl,st) :
		return cl (*st.split("-"))


co=Computer.seds("4000-2000-500")


#co = Computer ()
#co.pi = 4000
#co.mo = 2000
#co.cc = 500


print (co.com_th ())

