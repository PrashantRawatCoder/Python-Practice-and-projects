from functools import lru_cache
a=input("Enter \n")

@lru_cache(maxsize=100)
def hi(k):
	print("\n\n")
	for i in range (k):
		print(a)
	print("Complited")

hi(3)
print("hi 1")
hi(4)
print("hi completed 2")
hi(3)
print("hi completed 3")