from playsound import playsound 
import speech_recognition as sr
import random
import pyttsx3
import time
import gtts
import sys
import os

def spre():
	vcr=sr.Recognizer()
	
	harvard = sr.AudioFile('harvard.wav')
	with harvard as source:
	    audio = vcr.record(source)
	vcr.recognize_google(audio)

spre()
