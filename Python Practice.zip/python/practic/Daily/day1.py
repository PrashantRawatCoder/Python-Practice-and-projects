
# problem 1 : Solved without error

#def add_it_up(integer):
#    try :
#        integer=int(integer)
#        n = 0
#        for i in range(integer):
#            n+=integer-i
#        return n
#    except :
#        return 0


#inp = input("Enter a number :\n")
#print(add_it_up(inp))

#problem 2 : Solved without error

def encrypt(string,num):
    newstr,allstr="","abcdefghijklmnopqrstuvwxyz"
    for ltr in string:
        if ltr!=" ":
            if allstr.index(ltr)+num<=26:
                newstr+=allstr[allstr.index(ltr)+num]
            else :
                appen=allstr.index(ltr)+num-26
                newstr+=allstr[appen]
        else :
            newstr+=" "
    return newstr
    
    
print(encrypt("abcd xyz",4))

