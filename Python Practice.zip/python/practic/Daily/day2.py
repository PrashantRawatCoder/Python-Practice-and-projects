a =int(input("how maby number you : "))
l=[]
for i in range(a):
    print("Enter number ",i," :\n")
    l.append(int(input()))
inp=int(input("Tnter number : "))
i=0

for k in range(len(l)):
    for j in range(len(l)):
        if l[k]+l[j]==inp :
            print(l[k]," ",l[j])

#solved with very few effort