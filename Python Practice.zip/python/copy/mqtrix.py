# * coding=utf8
 
import sys
import random
import pygame
from pygame.locals import *
 
 
# Screen size
WIDTH = 800
HEIGHT = 600
 # Falling speed range
SPEED = [0, 9]
 # CODE String list
LEN = ['PHP','Python','C++','Java','C#','javascript','GoLang','Ruby','Android','Vue','swift','basic','.net']
 
 
 # Randomly generate a color
def randomColor():
	#return (0,238,0)
	return (random.randint(0, 255), random.randint(0, 255), random.randint(0, 255))
 
 
 # Randomly generate a speed
def randomSpeed():
	return random.randint(SPEED[0], SPEED[1])
 
 
 # Randomly generate a location
def randomPos():
	return (random.randint(0, WIDTH), -20)
 
 
 # Randomly generate a string
def randomCode():
	return LEN[random.randint(1,len(LEN))-1]
 
 # Randomly generate font size
def randomSize():
	return random.randint(12,36)
 
 # Define code wizard class
class Code(pygame.sprite.Sprite):
	def __init__(self):
		pygame.sprite.Sprite.__init__(self)
		self.code= randomCode()
		self.font = pygame.font.SysFont("Arial", randomSize())
		#self.font = pygame.font.Font('C:/Windows/Fonts/simhei.ttf', randomSize())
		
		self.speed = randomSpeed()
		self.image = self.font.render(self.code, True, randomColor())
		self.image = pygame.transform.rotate(self.image, random.randint(90, 90))
		self.rect = self.image.get_rect()
		self.rect.topleft = randomPos()
	def update(self):
		self.rect = self.rect.move(0, self.speed)
		if self.rect.top > HEIGHT:
			 #When the sprite position exceeds the screen, destroy
			self.kill()
pygame.init()
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption('code_rain')
clock = pygame.time.Clock()
codesGroup = pygame.sprite.Group()
while True:
	clock.tick(24) #frame number
	for event in pygame.event.get():
		 #Listener close event
		if event.type == QUIT:
			pygame.quit()
			sys.exit(0)
	screen.fill((1, 1, 1)) #fill the background color, equivalent to clear
	 #Create a new wizard
	codeobject = Code()
	codesGroup.add(codeobject)
	 # Monitor and destroy
	codesGroup.update()
	codesGroup.draw(screen)
	pygame.display.update()