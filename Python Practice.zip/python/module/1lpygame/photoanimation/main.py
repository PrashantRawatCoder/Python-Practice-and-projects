import pygame
import time

pygame.init()
screen = pygame.display.set_mode((1,1))
a=0
FPS=1
while True :
	l=[pygame.transform.scale(pygame.image.load("1.jpg"),(710,710)),pygame.transform.scale(pygame.image.load("4.jpg"),(710,710)),pygame.transform.scale(pygame.image.load("2.jpg"),(710,710)),pygame.transform.scale(pygame.image.load("3.jpg"),(710,710))]
	
	for event in pygame.event.get():
				
				if event.type==pygame.QUIT:
					run=False
	
	screen.blit(l[a],(0,350))
	pygame.display.update()
	time.sleep(0.00)
	a+=1
	if a == 4:
		a=0
	