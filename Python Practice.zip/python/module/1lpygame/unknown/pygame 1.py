import pygame
import time
tim=True
if tim:
	pygame.init()
	
	win = pygame.display.set_mode((500,500))
	pygame.display.set_caption("First Game")
	
	x = 50
	y = 50
	width = 40
	height = 60
	vel = 5
	
	run = True
	
	while run:
		pygame.time.delay(100)
		for event in pygame.event.get():
			if event.type == pygame.QUIT:
				run = False
		image=pygame.image.load("ni.jpg")
		IMAGE=pygame.image.load("usim.jpg")
		wide=pygame.image.load("wide.jpg")
		wid=pygame.image.load("wid.jpg")
		long=pygame.image.load("long.jpg")
		img=pygame.transform.scale(IMAGE, (600, 1100))
		image1=pygame.transform.scale(image, (600, 1100))
		win.fill((255,255,255))
		win.blit(long, (0,200))
		i=0
		ij=0
		pygame.mixer.music.load("ub.mp3")
		pygame.mixer.music.play()
		while True:
			if i %2!=0:
				if ij%2!=0:
					win.blit(wide, (0,0))
					ij+=1
					pygame.display.update()
					time.sleep(0.5)
				elif ij %2==0:
					win.blit(wid, (0,0))
					ij+=1
					pygame.display.update()
					time.sleep(0.5)
				win.blit(image1, (150,210))
				i+=1
				pygame.display.update()
				time.sleep(1)
			elif i %2==0:
				if ij%2!=0:
					win.blit(wide, (0,0))
					ij+=1
					pygame.display.update()
					time.sleep(0.2)
				elif ij %2==0:
					win.blit(wid, (0,0))
					ij+=1
					pygame.display.update()
					time.sleep(0.2)
				win.blit(img, (150,210))
				i+=1
				pygame.display.update()
				time.sleep(1)
	    
	    
	    
	    
	    
	pygame.quit()