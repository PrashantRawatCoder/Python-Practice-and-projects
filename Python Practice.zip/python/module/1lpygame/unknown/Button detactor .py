import pygame
from pygame.locals import *
import time
import sys


def main():
	pygame.init()
	clock = pygame.time.Clock()
	fps = 60
	
	screen = pygame.display.set_mode((200,200))
	
	button1=pygame.Rect(10,1000,200,300)
	button2=pygame.Rect(260,1000,200,300)
	button3=pygame.Rect(510,1000,200,300)
	bcolor=[255,255,255]
	font=pygame.font.SysFont('Arial', 30)
	while True:
	
		for event in pygame.event.get():
			if event.type == pygame.QUIT:
				return False
			
			if event.type == pygame.MOUSEBUTTONDOWN:
				mouse_p=event.pos
				
				
				if button1.collidepoint(mouse_p):
					
					bcolor=[0,0,255]
				
				elif button2.collidepoint(mouse_p):
					bcolor=[0,255,0]
				
				elif button3.collidepoint(mouse_p):
					bcolor=[255,0,0]
				
		screen.fill((255,255,255))
			
		pygame.draw.rect(screen,bcolor,pygame.Rect(100, 200, 500, 500))	
		pygame.draw.rect(screen, [0, 0, 255], button1)
		screen.blit(font.render('Blue', True, (0,0,0)), (70, 1110))
		pygame.draw.rect(screen, [0, 255, 0], button2)
		pygame.draw.rect(screen, [255, 0, 0], button3)
		pygame.display.update()
		clock.tick(fps)
	
	pygame.quit()
	sys.exit

if __name__=="__main__":
	main()
					