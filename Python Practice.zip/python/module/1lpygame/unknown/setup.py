from cx_Freeze import setup, Executable

base = None    

executables = [Executable("main.py", base=base)]

packages = ["idna","pygame","random","sys","time"]
options = {
    'build_exe': {    
        'packages':packages,
    },    
}

setup(
    name = "<Snake Game>",
    options = options,
    version = "1",
    description = 'By Prashant Rawat',
    executables = executables
)