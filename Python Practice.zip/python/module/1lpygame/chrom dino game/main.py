import pygame
from pygame import *
import random
import sys

def bmu():
	butprs=pygame.mixer.Sound("hit.ogg")
	butprs.play()
	





class main():
	
	screen = pygame.display.set_mode((1,1))
	imgn=0
	plhi=559
	run = True
	gameover=False
	plupt=True
	plup=False
	imch=False
	cacch=True
	highsc=False
	cacb=500
	coun=3
	cacl=[]
	playerr=0
	imgl=pygame.transform.scale
	imgl2=pygame.image.load
#	img load
	plim=pygame.image.load("dra1.PNG")
	plim1=pygame.image.load("dra2.PNG")
	plim2=pygame.image.load("dra3.PNG")
	plim3=pygame.image.load("dra4.PNG")
	playerdie=imgl2("dra5.png")
	bacg=pygame.image.load("background.png")
	
	tree5 = imgl(imgl2("tree4.png"),(62,60))
	tree6= imgl(imgl2("tree5.png"),(31,56))
	tree2= imgl(imgl2("tree1.png"),(99,62))
	
	tree1 = imgl(imgl2("tree.png"),(88,80))
	tree3= imgl(imgl2("tree2.png"),(100,80))
	tree4= imgl(imgl2("tree3.png"),( 45,79))
	
	
	bacmove=False
	
	bacx=0
	bacx2=710
	tree1x=710
	tree2x=1420
	stree=[tree5,tree6,tree2]
	btree=[tree1,tree3,tree4]
	treesp=20
	playerl=[plim,plim1,plim2,plim3]
	rtree=stree[0]
	rt=599
	rtree2=stree[1]
	rt2=599
	score=0
	buon=pygame.Rect(290,1000,150,150)
	replay=pygame.image.load("replay.jpg")
	scorea=0.5
	rectup=True
	rectovery=1300
	con=21
	contr=False
	paused=False
	highscp=True
	try :
		with open('.h_s.txt' ,'r' ) as hs:
			hisc=hs.read()
	except :
		with open('.h_s.txt','w') as hs:
			hs.write("10")
		with open('.h_s.txt' ,'r' ) as hs:
			hisc=hs.read()
	pygame.init()
	pygame.mixer.music.load("1st sound.mp3")
	pygame.mixer.music.play(-1)
	pygame.mixer.music.set_volume(0.2)
	while run:
		
		if gameover:
			
			screen.blit(pygame.transform.scale(playerdie,(75,85)),(50,plhi))
			
			if int(str(hisc).split(".")[0])==int(str(score).split(".")[0]):
				hisc=score
				with open('.h_s.txt','w') as hs:
					hs.write(str(hisc))
		
			pygame.mixer.Sound("hit.mp3").play()
			while gameover:
				pygame.init()
				font1 = pygame.font.SysFont('chalkduster.ttf', 150)
				font2 = pygame.font.SysFont('chalkduster.ttf', 120)
				font3 = pygame.font.SysFont('chalkduster.ttf', 100)
				fon=pygame.font.SysFont('Arial', 60)
				sf=pygame.font.SysFont('Arial', 100)
				repr=pygame.Rect([320,500,80,80])
				quitr=pygame.Rect(75,800,600,80)
				reshir=pygame.Rect(30,950,660,80)
				abor=pygame.Rect(75,1100,600,80)
				for event in pygame.event.get():
					
					if event.type==pygame.QUIT:
						run=False
					if event.type==pygame.MOUSEBUTTONDOWN:
						finp=event.pos
						
						if repr.collidepoint(finp):
							bmu()
							imgn=0
							plhi=559
							run = True
							gameover=False
							plupt=True
							plup=False
							imch=False
							cacch=True
							cacb=500
							coun=3
							cacl=[]
							playerr=0
							paused=False
							highsc=False
							bacx=0
							bacx2=710
							tree1x=710
							tree2x=1420
							stree=[tree5,tree6,tree2]
							btree=[tree1,tree3,tree4]
							treesp=20
							
							rtree=stree[0]
							rt=599
							rtree2=stree[1]
							rt2=599
							score=0
							rectup=True
							rectovery=1300
							highscp=True
							scorea=0.5
							with open('.h_s.txt' ,'r' ) as hs:
								hisc=hs.read()
						elif quitr.collidepoint(finp):
							bmu()
							run=False
							gameover=False
						elif reshir.collidepoint(finp):
							bmu()
							with open('.h_s.txt','w') as hs:
								hs.write("10")
							hisc=10
							con=0
							contr=True
						elif abor.collidepoint(finp):
							bmu()
							smlt=pygame.font.SysFont('Arial', 50)
							
							hrun=True
							while hrun:
								
								screen.fill((100,30,250))
								Back=pygame.Rect(247,1200,200,70)
								
								pygame.draw.rect(screen,[200,0,0],Back)
								
								
								screen.blit(fon.render('Back', True, (0,205,20)), (249, 1202))
								screen.blit(fon.render('By ', True, (0,205,20)), (20, 52))
								screen.blit(fon.render('Prashant Rawat', True, (0,205,20)), (20, 152))
								
								screen.blit(fon.render('India Haryana - Palwal', True, (0,205,20)), (20, 252))
								
								screen.blit(fon.render('Age = 12', True, (0,205,20)), (20, 352))
								screen.blit(fon.render('Email :', True, (0,205,20)), (247, 452))
								screen.blit(smlt.render('prashantjnv12@gmail.com', True, (0,205,20)), (40, 552))
								pygame.display.update()
								for event in pygame.event.get():
											if event.type == pygame.QUIT:
												run=False
											if event.type == pygame.MOUSEBUTTONDOWN:
												m_p=event.pos
												
												if Back.collidepoint(m_p):
													bmu()
													hrun=False
													imgn=0
													scorea=0.5
													plhi=559
													paused=False
													run = True
													gameover=False
													plupt=True
													plup=False
													imch=False
													cacch=True
													bacmove=False
													highsc=False
													cacb=500
													coun=3
													cacl=[]
													playerr=0
															
													bacx=0
													bacx2=710
													tree1x=710
													tree2x=1420
													stree=[tree5,tree6,tree2]
													btree=[tree1,tree3,tree4]
													treesp=20
													
													rtree=stree[0]
													rt=599
													rtree2=stree[1]
													rt2=599
													score=0
													rectup=True
													rectovery=1300
													highscp=True
													with open('.h_s.txt' ,'r' ) as hs:
														hisc=hs.read()

				gametxt=font1.render('GameOver', True, [0,0,250])
				screen.blit(gametxt,(100,380))
				screen.blit(pygame.transform.scale(replay,(80,80)),(320,530))
				
				
				pygame.draw.rect(screen,[150,50,50],[20,rectovery,680,1000])
				if rectup:
					rectovery-=120
				if rectovery<730:
					rectup=False
				
				if not rectup:
					#pygame.draw.rect(screen,[255,255,255],reshir)
					quit=font2.render('Quit', True, [0,200,0])
					screen.blit(quit,(250,800))
					rehi=font2.render('Reset HighScore', True, [0,200,0])
					screen.blit(rehi,(30,950))
					
					about=font2.render('About', True, [0,200,0])
					
					screen.blit(about,(250,1100))
					pygame.draw.rect(screen,[255,255,255],[50,200,800,100])
					pygame.draw.rect(screen,[255,255,255],[50,300,800,70])
					cortxt = font1.render('Score : '+str(score).split(".")[0], True, [0,170,0])
					screen.blit(scortxt,(50,300))
					hsctxt = font3.render('High Score : '+str(hisc).split(".")[0], True, [0,170,0])
					screen.blit(hsctxt,(50,200))
					
					if con<20:
								pygame.draw.rect(screen,[255,255,255],[260,1250,200,60])
								font1 = pygame.font.SysFont('chalkduster.ttf', 70)
								done=font1.render('Done !',True,[0,0,0])
								screen.blit(done,(270,1260))
								pygame.display.update()
								con+=1
				
				pygame.display.update()
			
		
		
		
		
		else :	
			pygame.init()
			font1 = pygame.font.SysFont('chalkduster.ttf', 100)
			font2 = pygame.font.SysFont('chalkduster.ttf', 150)
			
			
			
			
			
			if bacmove:
				tree1x-=treesp
				tree2x-=treesp
				score+=scorea
			
			
			pausr=pygame.Rect(390,710,310,80)
			quitr=pygame.Rect(50,710,200,80)
			for event in pygame.event.get():
				
				if event.type==pygame.QUIT:
					run=False
				if event.type==pygame.MOUSEBUTTONDOWN:
					finp=event.pos
					
				
					if pausr.collidepoint(finp):
						bmu()
						paused=True
							
							
					elif quitr.collidepoint(finp):
						bmu()
						run=False
						
					else:
						pygame.mixer.Sound("wing.ogg").play()
						bacmove=True
						
						plup=True
			
			if not paused:
				ptxt="Pause"
			elif paused:
				ptxt="Continue"
			paustxt=font1.render(ptxt,True,[200,200,200])
			quitxt=font1.render("Quit",True,[200,200,200])

			
			if bacmove:
				
				
				bacx-=28.4
				bacx2-=28.4
					
			
			
			
			if plup:
				if plupt:
					if plhi<451:
						plupt=False
					plhi-=20
				else :
					if plhi>558:
						plhi=559
						plup=False
						plupt=True
					else :
						plhi+=20
			
			
			screen.fill((255,255,255))
			
				
			
			if bacx<-709:
				bacx=710
				
					
			screen.blit(pygame.transform.scale(bacg,(710,790)),(bacx,0))
			if bacx2<-709:
				bacx2=710
				
				
			screen.blit(pygame.transform.scale(bacg,(710,790)),(bacx2,0))
			
			if bacmove:
				playerr+=1
				if playerr==4:
					playerr=0
			
			screen.blit(pygame.transform.scale(playerl[playerr],(75,85)),(50,plhi))
			playerrect=pygame.Rect(50,plhi+10,55,65)
			
			
			scortxt = font1.render('Score : '+str(score).split(".")[0], True, [120,120,120])
			screen.blit(scortxt,(50,300))
			hsctxt = font1.render('High Score : '+str(hisc).split(".")[0], True, [120,120,120])
			screen.blit(hsctxt,(50,200))
			
			
			if tree1x<-100:
				rtc=random.choice([stree,btree])
				rtree=random.choice(rtc)
				if rtc==stree:
					rt=599
				else :
					rt=577
				tree1x=1420
			if tree2x<-100:
				rtl=random.choice([stree,btree])
				rtree2=random.choice(rtl)
				if rtl == stree:
					rt2=599
				else :
					rt2=577
				tree2x=1420
			screen.blit(rtree,(tree1x,rt))
			screen.blit(rtree2,(tree2x,rt2))
			tree1rect=pygame.Rect(tree1x,rt,rtree.get_width(),rtree.get_height())
			tree2rect=pygame.Rect(tree2x,rt2,rtree2.get_width(),rtree2.get_height())
			
			if playerrect.colliderect(tree1rect) or playerrect.colliderect(tree2rect):
				gameover=True
			
			if bacmove:
				pygame.draw.rect(screen,[255,5,25],pausr)
				screen.blit(paustxt,(392,715))
			pygame.draw.rect(screen,[10,20,205],quitr)
			screen.blit(quitxt,(60,717))
			
			if score%100<1 and score>99:
				pygame.mixer.Sound("jump.ogg").play()
				treesp+=3
			if score%200<1 and score>199:
				scorea+=0.5
			if score>=int(str(hisc).split(".")[0]):
				hswr = font2.render('High Score !', True, [255,0,0])
				hisc=score
				screen.blit(hswr,(50,50))
				if highscp:
					highsc=True
				if highsc:
					pygame.mixer.Sound("highsc.mp3").play()
					highsc=False
					highscp=False
					
			if paused:
				pygame.display.update()
				prun=True
				while prun:
					
					for event in pygame.event.get():
						if event.type==pygame.QUIT:
							run=False
						if event.type==pygame.MOUSEBUTTONDOWN:
							finp=event.pos
							if pausr.collidepoint(finp):
								prun=False
								paused=False
								bmu()
							elif quitr.collidepoint(finp):
								gameover=True
								prun=False
								bmu()
								
					pygame.display.update()
						
				
			
			
			
			
	
			
			

			
	
			
			
			pygame.display.update()
	pygame.quit()
	sys.exit
		
		
		
		
		
		
		
		
		
		
		
		
		
	
if __name__ =="__main__":
	main()