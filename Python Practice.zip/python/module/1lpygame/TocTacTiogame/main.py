import pygame
import sys


def main():
    screen=pygame.display.set_mode((720,1800))
    pygame.init()
    exit=False
    #Variables
    touched=False
    
    table=pygame.image.load("img/board.jpg")
    s1=[17,397,200,200]
    s2=[250,397,200,200]
    s3=[495,397,200,200]
    s4=[17,645,200,200]
    s5=[250,645,200,200]
    s6=[495,645,200,200]
    s7=[17,883,200,200]
    s8=[250,883,200,200]
    s9=[495,883,200,200]
    
    sic1=True
    si1=False
    cros=False
    
    while not exit:
        GAMEOVER=False
        if GAMEOVER:
            pass
        else:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    exit=True
                if event.type == pygame.MOUSEBUTTONDOWN:
                    mpos=event.pos
                    touched=True
                    if cros:
                        cros=False
                    else :
                        cros=True
                    if sic1:
                        if pygame.Rect(s1).collidepoint(mpos):
                            si1=True
                            sic1=False
            screen.fill([0,0,255])
            screen.blit(pygame.transform.scale(table,(710,710)),(5,390))
            
            
            
            
            pygame.draw.rect(screen,[100,100,100],s1)
            pygame.draw.rect(screen,[100,100,100],s2)
            pygame.draw.rect(screen,[100,100,100],s3)
            pygame.draw.rect(screen,[100,100,100],s4)
            pygame.draw.rect(screen,[100,100,100],s5)
            pygame.draw.rect(screen,[100,100,100],s6)
            pygame.draw.rect(screen,[100,100,100],s7)
            pygame.draw.rect(screen,[100,100,100],s8)
            pygame.draw.rect(screen,[100,100,100],s9)
            
         
                
            if touched:       
                if si1:
                    screen.blit(pygame.transform.scale(pygame.image.load("img/cross.jpg" if cros else "img/circle.jpg"),(200,200)),(s1[0],s1[1]))
            
            pygame.display.update()
                
                    
                
    
if __name__=="__main__":
    main()