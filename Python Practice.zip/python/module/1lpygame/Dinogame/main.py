import pygame
from pygame import *
import random
import time
import sys


class main():
	
	screen = pygame.display.set_mode((1,1))
	imgn=1
	plhi=510
	run = True
	gameover=False
	plupt=True
	plup=False
	imch=False
	cacch=True
	cacb=500
	coun=3
	cacl=[]
	playerr=1
	plim=pygame.image.load("player1.jpg")
	plim1=pygame.image.load("player1.jpg")
	plim2=pygame.image.load("player2.jpg")
	plim3=pygame.image.load("player2.jpg")
	plim4=pygame.image.load("player0.jpg")
	plim5=pygame.image.load("player0.jpg")
	playerl=[plim,plim1,plim2,plim3,plim4,plim5]
	buon=pygame.Rect(290,1000,150,150)
	rncac=random.choice([pygame.image.load("cac0.jpg"),pygame.image.load("cac1.jpg"),pygame.image.load("cac2.jpg"),pygame.image.load("cac3.jpg"),pygame.image.load("cac4.jpg"),0])
	while run:
		if rncac!=0:
			cacl.append(rncac)
			
		pygame.init()
		
		cacr=pygame.Rect([cacb,540,30,60])
		for event in pygame.event.get():
			
			if event.type==pygame.QUIT:
				run=False
			if event.type==pygame.MOUSEBUTTONDOWN:
				finp=event.pos
				if buon.collidepoint(finp):
					plup=True
				
					
					
		
		if plup:
			if plupt:
				if plhi<371:
					plupt=False
				plhi-=2
			else :
				if plhi>498:
					plhi=500
					plup=False
					plupt=True
				else :
					plhi+=1.5
		
		
		screen.fill((57,57,57))
		
			
		#for obj in cacl:
#			for img,bre in obj:
#				if img==pygame.image.load("cac0.jpg"):
#					pass
#				screen.blit(img,(bre,530))
		screen.blit(pygame.transform.scale(playerl[playerr],(75,85)),(50,plhi))
		playerr+=1
		if playerr==6:
			playerr=0
		
		plr=pygame.Rect(50,plhi,75,85)
		
		#pygame.draw.rect(screen,(200,200,200),cacr)
		cacb-=1.5
		pygame.draw.rect(screen,(100,100,100),[0,600,780,10])
		if cacb<180:
			rncac=random.choice([pygame.image.load("cac0.jpg"),pygame.image.load("cac1.jpg"),pygame.image.load("cac2.jpg"),pygame.image.load("cac3.jpg"),pygame.image.load("cac4.jpg"),0])
			if rncac!=0:
				cacl.append([rncac,600])
		
	#	if plr.colliderect(cacr):
#			run=False
		coun+=1
		pygame.draw.rect(screen,(165,0,0),buon)
		pygame.display.update()
		
		
		
		
		
		
		
		
		
		
		
		
		
	
if __name__ =="__main__":
	main()