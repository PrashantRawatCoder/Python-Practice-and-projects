import pygame
import sys

run=True
red=pygame.image.load("red.png")
green=pygame.image.load("green.png")
dgreen=pygame.image.load("d green.png")
orange=pygame.image.load("orange.png")
pink=pygame.image.load("pink.png")
purple=pygame.image.load("purple.png")
blue=pygame.image.load("blue.png")
dblue=pygame.image.load("d blue.png")
brown=pygame.image.load("brown.png")
white=pygame.image.load("white.png")
black=pygame.image.load("black.png")
yellow=pygame.image.load("yellow.png")
skin=pygame.image.load("skin.png")
grey=pygame.image.load("grey.png")

bursh=pygame.image.load("brush.png")

screen=pygame.display.set_mode((500,2000))

coler=black


while run:
	
	
	screen.fill((255,255,255))

	pygame.draw.rect(screen,[8,50,187],pygame.Rect(0,1000,720,400))
	screen.blit(pygame.transform.scale(red,(85,85)),(50,1010))
	redr=pygame.Rect(50,1010,85,85)
	screen.blit(pygame.transform.scale(green,(85,85)),(140,1010))
	greenr=pygame.Rect(140,1010,85,85)
	screen.blit(pygame.transform.scale(dgreen,(85,85)),(215,1010))
	dgreenr=pygame.Rect(215,1010,85,85)
	screen.blit(pygame.transform.scale(orange,(85,85)),(300,1010))
	oranger=pygame.Rect(300,1010,85,85)
	screen.blit(pygame.transform.scale(pink,(85,85)),(385,1010))
	pinkr=pygame.Rect(385,1010,85,85)
	screen.blit(pygame.transform.scale(purple,(85,85)),(470,1010))
	purpler=pygame.Rect(470,1010,85,85)
	screen.blit(pygame.transform.scale(blue,(85,85)),(565,1010))
	bluer=pygame.Rect(565,1010,85,85)
	screen.blit(pygame.transform.scale(dblue,(85,85)),(50,1110))
	dbluer=pygame.Rect(50,1110,85,85)
	screen.blit(pygame.transform.scale(brown,(85,85)),(140,1110))
	brownr=pygame.Rect(140,1110,85,85)
	screen.blit(pygame.transform.scale(white,(85,85)),(215,1110))
	whiter=pygame.Rect(215,1110,85,85)
	screen.blit(pygame.transform.scale(black,(85,85)),(300,1110))
	blackr=pygame.Rect(300,1110,85,85)
	screen.blit(pygame.transform.scale(yellow,(85,85)),(385,1110))
	yellowr=pygame.Rect(385,1110,85,85)
	screen.blit(pygame.transform.scale(skin,(85,85)),(470,1110))
	skinr=pygame.Rect(480,1110,85,85)
	screen.blit(pygame.transform.scale(grey,(85,85)),(565,1110))
	greyr=pygame.Rect(565,1110,85,85)
	
	
	screen.blit(pygame.transform.scale(black,(30,30)),(50,1290))
	blacks=pygame.Rect(50,1290,30,30)
	screen.blit(pygame.transform.scale(black,(60,60)),(140,1270))
	blackns=pygame.Rect(140,1270,60,60)
	screen.blit(pygame.transform.scale(black,(90,90)),(260,1250))
	blackn=pygame.Rect(260,1250,90,90)
	screen.blit(pygame.transform.scale(black,(105,105)),(390,1235))
	blacknb=pygame.Rect(390,1235,105,105)
	screen.blit(pygame.transform.scale(black,(120,120)),(550,1220))
	blackb=pygame.Rect(550,1220,120,120)
	pygame.display.update()
	
	for event in pygame.event.get():
		if event.type == pygame.QUIT:
			run=False
		if event.type == pygame.MOUSEBUTTONDOWN:
			pos=event.pos
			
			if redr.collidepoint(pos):
				drco=red
			elif .collidepoint(pos):
				drco=
			elif .collidepoint(pos):
				drco=
			elif .collidepoint(pos):
				drco=
			elif .collidepoint(pos):
				drco=
			elif .collidepoint(pos):
				drco=
			elif .collidepoint(pos):
				drco=
			elif .collidepoint(pos):
				drco=
			elif .collidepoint(pos):
				drco=
			elif .collidepoint(pos):
				drco=
			elif .collidepoint(pos):
				drco=
			elif .collidepoint(pos):
				drco=
			elif .collidepoint(pos):
				drco=
	
	
	


pygame.quit()
sys.exit