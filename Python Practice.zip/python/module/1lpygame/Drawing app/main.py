import pygame
def imgpr(image,size,pose):
	screen.blit(pygame.transform.scale(pygame.image.load(image),size),pose)
	pygame.display.update()
	
screen=pygame.display.set_mode((500,2000))

colis=[["red.png",(85,85),(110,85)]]
while True:
	for col in colis:
		imgpr(col[0],col[1],col[2])
		pygame.display.update()