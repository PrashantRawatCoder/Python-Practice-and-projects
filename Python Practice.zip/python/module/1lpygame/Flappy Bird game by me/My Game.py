import pygame
pygame.init()

win=pygame.display.set_mode((12,5))
pygame.display.set_caption("Radhe Krishna")

exit=False
gameover=False

while not exit:
	for event in pygame.event.get():
		print(event)


pygame.quit()
quit()