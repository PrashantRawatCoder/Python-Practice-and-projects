import pygame

win = pygame.display.set_mode((1400,700))

class Player():
	def  __init__(self,x,y,width,hight,color):
		self.x= x
		self.y= y
		self.width= width
		self.height= height
		self.color= color
		self.rect= (x,y,width,height)
	
	def rectdraw(self,win):
		pygame.draw.rect(win,self.color,self.rect)
	
	def move(self):
		
	
	

def redrawwin():
	win.fill([255,255,255])
	pygame.display.update()

def main():
	run=True
	while run:
		for events in pygame.event.get():
			if events.type==pygame.QUIT:
				run= False
				pygame.quit()
		#redrawwin()

#main()
