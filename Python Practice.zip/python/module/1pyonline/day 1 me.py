import pygame
win = pygame.display.set_mode((1400,700))

class Player():
	def  __init__(self,x,y,width,height,color):
		self.x= x
		self.y= y
		self.width= width
		self.height= height
		self.color= color
		self.vel=10
		self.rect= (x,y,width,height)
	
	def draw(self,win,left,right,up,down):
		pygame.draw.rect(win,self.color,self.rect)
		
		pygame.draw.rect(win,[0,0,0],left)
		pygame.draw.rect(win,[0,0,0],right)
		pygame.draw.rect(win,[0,0,0],up)
		pygame.draw.rect(win,[0,0,0],down)
	
	def move(self,left,right,up,down):
		pygame.init()
		for event in pygame.event.get():
			if event.type == pygame.MOUSEBUTTONDOWN:
				mouse_p=event.pos
				if up.collidepoint(mouse_p):
						print("up")
						self.x-=self.vel
				if right.collidepoint(mouse_p):
						self.y+=self.vel
				if left.collidepoint(mouse_p):
						self.y-=self.vel
				if down.collidepoint(mouse_p):
						self.x+=self.vel
		self.rect = (self.x, self.y, self.width, self.height)
	
	

def redrawwin(player,win,left,right,up,down):
	win.fill([255,255,255])
	player.draw(win,left,right,up,down)
	pygame.display.update()

def main():
	left=pygame.Rect(145,1120,150,150)
	right=pygame.Rect(455,1120,150,150)
	up=pygame.Rect(300,1080,150,150)
	down=pygame.Rect(300,1240,150,150)
	run=True
	pygame.init()
	p = Player(50,50,100,100,(0,255,0))
	while run:
		
		for events in pygame.event.get():
			if events.type==pygame.QUIT:
				run= False
				pygame.quit()
		p.move(left,right,up,down)
		redrawwin(p,win,left,right,up,down)

main()
