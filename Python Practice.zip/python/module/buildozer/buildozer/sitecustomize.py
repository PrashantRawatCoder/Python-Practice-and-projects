from os.path import join, dirname
import sys
sys.path.append(join(dirname(__file__), '_applibs'))
